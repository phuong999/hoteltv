const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./dashboard.db');

db.serialize(() => {
  db.run("CREATE TABLE IF NOT EXISTS links (id INTEGER PRIMARY KEY, name TEXT, url TEXT, category TEXT, logo TEXT, description TEXT)");

  // Clear existing data and insert new data
  db.run("DELETE FROM links");

  // Activities - Local Agencies with proper logos
  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Tiger Trail', 'https://www.tiger-trail.com/', 'Activities', 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=120&h=120&fit=crop&crop=center', 'Adventure tours and trekking experiences']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Ock Pop Tok', 'https://ockpoptok.com/', 'Activities', 'https://images.unsplash.com/photo-1582639510494-c80b5de9f148?w=120&h=120&fit=crop&crop=center', 'Traditional textile and craft center']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Kuang Si Falls Tour', '#', 'Activities', 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=120&h=120&fit=crop&crop=center', 'Beautiful waterfall and swimming spots']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Mekong River Cruise', '#', 'Activities', 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=120&h=120&fit=crop&crop=center', 'Scenic river cruise experience']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Pak Ou Caves Tour', '#', 'Activities', 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=120&h=120&fit=crop&crop=center', 'Sacred caves with Buddha statues']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Traditional Cooking Class', '#', 'Activities', 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=120&h=120&fit=crop&crop=center', 'Learn authentic Lao cuisine']);

  // Restaurants & Bars with proper logos
  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['L\'Elephant Restaurant', '#', 'Restaurants', 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=120&h=120&fit=crop&crop=center', 'Fine French cuisine in historic setting']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Tamarind Restaurant', '#', 'Restaurants', 'https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?w=120&h=120&fit=crop&crop=center', 'Authentic Lao cuisine and cooking classes']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Icon Klub', '#', 'Restaurants', 'https://images.unsplash.com/photo-1546171753-97d7676e4602?w=120&h=120&fit=crop&crop=center', 'Trendy nightlife and cocktail bar']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Utopia Bar', '#', 'Restaurants', 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=120&h=120&fit=crop&crop=center', 'Riverside bar with stunning sunset views']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Joma Bakery Cafe', '#', 'Restaurants', 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=120&h=120&fit=crop&crop=center', 'Western-style bakery and coffee shop']);

  // Entertainment - IPTV and Streaming Services with actual company logos
  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Live TV - IPTV', '#iptv', 'Entertainment', 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=120&h=120&fit=crop&crop=center', 'Live television channels']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Netflix', 'https://www.netflix.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2020/04/Netflix-Logo.png', 'Movies and TV series streaming']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Disney+', 'https://www.disneyplus.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2022/01/Disney-Plus-Logo.png', 'Disney, Marvel, Star Wars content']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Amazon Prime Video', 'https://www.primevideo.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2021/02/Amazon-Prime-Video-Logo.png', 'Prime Video streaming service']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['HBO Max', 'https://www.hbomax.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2022/01/HBO-Max-Logo.png', 'Premium HBO content and movies']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['YouTube', 'https://www.youtube.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2020/04/YouTube-Logo.png', 'Video sharing and content platform']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Apple TV+', 'https://tv.apple.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2022/01/Apple-TV-Logo.png', 'Apple original shows and movies']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Hulu', 'https://www.hulu.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2020/05/Hulu-Logo.png', 'TV shows and movies streaming']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Spotify', 'https://www.spotify.com/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2020/06/Spotify-Logo.png', 'Music streaming service']);

  db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", 
    ['Twitch', 'https://www.twitch.tv/', 'Entertainment', 'https://logos-world.net/wp-content/uploads/2020/10/Twitch-Logo.png', 'Live gaming and entertainment streams']);
});

module.exports = {
  getLinks: () => {
    return new Promise((resolve, reject) => {
      db.all("SELECT * FROM links ORDER BY category, name", [], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },
  getLinksByCategory: (category) => {
    return new Promise((resolve, reject) => {
      db.all("SELECT * FROM links WHERE category = ? ORDER BY name", [category], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },
  addLink: (name, url, category, logo, description = '') => {
    return new Promise((resolve, reject) => {
      db.run("INSERT INTO links (name, url, category, logo, description) VALUES (?, ?, ?, ?, ?)", [name, url, category, logo, description], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }
};